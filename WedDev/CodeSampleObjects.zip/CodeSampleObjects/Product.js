	//Object Definition
function Product(aName, aCode, aPrice)
	{
		this.name = aName;
		this.code = aCode;
		this.price = aPrice;

		Product.prototype.getPrice = getPrice;
		//Product Bluetooth Speaker.$59.95
	
		function getPrice()
		{
			var pricing = "$";
			pricing = pricing+this.price;
			return pricing;
		}

	}

	//Constructor
